document.addEventListener('DOMContentLoaded', function () {
    const toggleBtn = document.querySelector('#togglePassword');
    const passwordInput = document.querySelector('#password');
    if (toggleBtn && passwordInput) {
        toggleBtn.addEventListener('click', function () {
            const isPassword = passwordInput.getAttribute('type') === 'password';
            passwordInput.setAttribute('type', isPassword ? 'text' : 'password');
            this.textContent = isPassword ? '🕶️' : '👁️';
        });
    }
});